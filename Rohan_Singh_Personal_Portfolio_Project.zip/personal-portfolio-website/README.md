# Personal Portfolio Website — Rohan Singh

A responsive, full-stack personal portfolio built for the internship task.

## Features
- Responsive portfolio layout with About, Skills, Projects and Contact sections
- Frontend: HTML5, CSS3 and JavaScript
- Backend: Node.js and Express REST API
- Database: MongoDB with Mongoose models for projects and contact messages
- Project list loaded dynamically from `/api/projects`
- Contact form posts messages to `/api/contact`
- Demo project cards are available even before MongoDB is connected

## Run locally
1. Install Node.js 18 or later.
2. Extract this project and open its folder in a terminal.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env` and add your MongoDB Atlas connection string:
   ```env
   PORT=5000
   MONGODB_URI=mongodb+srv://USERNAME:PASSWORD@cluster0.example.mongodb.net/portfolio
   ```
5. Start the app:
   ```bash
   npm start
   ```
6. Open `http://localhost:5000`.

Without a valid MongoDB connection, the site still displays its demo project cards. Saving contact messages and adding projects require MongoDB.

## Deploy online
### Option A — Render (full-stack)
1. Push this folder to a new GitHub repository.
2. In Render, create a **Web Service** and connect that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables `MONGODB_URI` and (optionally) `PORT`.
6. Deploy. Render will provide a public URL such as `https://your-portfolio.onrender.com`.

### MongoDB Atlas
1. Create a free cluster in MongoDB Atlas.
2. Create a database user and allow your deployment host in Network Access.
3. Copy the connection string and set it as `MONGODB_URI` in Render environment variables.

## Publish to GitHub
1. Create a repository named `personal-portfolio-website` on GitHub.
2. Upload the extracted project files (or push with Git).
3. Paste the GitHub repository URL or your deployed Render URL into the internship submission form.

## Personalize before final submission
- Confirm the name, university and course details in `public/index.html`.
- Replace “Add your email address here” with your real contact email.
- Replace the sample project links with your own GitHub project links.
- Update project descriptions and skills to match work you have actually completed.
- Update the sample project cards in `server.js` if needed.

## API endpoints
- `GET /api/health` — server/database status
- `GET /api/projects` — list portfolio projects
- `POST /api/projects` — create a project (MongoDB required)
- `POST /api/contact` — save a contact message (MongoDB required)
