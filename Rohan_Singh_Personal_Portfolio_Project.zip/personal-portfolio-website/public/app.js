const projectsGrid = document.getElementById("projectsGrid");
const symbols = ["✧", "⌘", "✳", "▣", "⌁"];

async function loadProjects() {
  try {
    const response = await fetch("/api/projects");
    const projects = await response.json();
    projectsGrid.innerHTML = projects.map((project, index) => `
      <article class="project-card">
        <div class="project-visual"><span class="project-number">0${index + 1}</span><span class="project-symbol">${symbols[index % symbols.length]}</span></div>
        <div class="project-body">
          <span class="project-category">${escapeHtml(project.category)}</span>
          <h3>${escapeHtml(project.title)}</h3>
          <p>${escapeHtml(project.description)}</p>
          <div class="tags">${(project.tech || []).map(t => `<span>${escapeHtml(t)}</span>`).join("")}</div>
          ${project.link ? `<a class="project-link" href="${safeUrl(project.link)}" target="_blank" rel="noopener noreferrer">View project ↗</a>` : ""}
        </div>
      </article>`).join("");
  } catch {
    projectsGrid.innerHTML = '<p class="loading">Projects could not be loaded. Please start the server and refresh.</p>';
  }
}
function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function safeUrl(value = "") {
  try { const u = new URL(value); return ["http:", "https:"].includes(u.protocol) ? u.href : "#"; }
  catch { return "#"; }
}

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("navLinks").classList.toggle("open");
});
document.querySelectorAll(".nav-links a").forEach(link => link.addEventListener("click", () => document.getElementById("navLinks").classList.remove("open")));

document.getElementById("contactForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const status = document.getElementById("formStatus");
  const payload = Object.fromEntries(new FormData(form).entries());
  status.textContent = "Sending…";
  try {
    const response = await fetch("/api/contact", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Message could not be sent.");
    status.textContent = result.message;
    form.reset();
  } catch (error) {
    status.textContent = error.message + " (Check MongoDB setup.)";
  }
});
loadProjects();
