require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const mongoose = require("mongoose");
const Project = require("./src/Project");
const Message = require("./src/Message");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const starterProjects = [
  { title: "Smart Patient Record System", category: "Full Stack", description: "A simple digital patient-record workflow with structured records and search.", tech: ["HTML", "CSS", "JavaScript", "MongoDB"], link: "https://github.com/" },
  { title: "Personal Portfolio Website", category: "Web Development", description: "A responsive portfolio to present projects, technical skills and contact details.", tech: ["HTML", "CSS", "JavaScript", "Node.js"], link: "https://github.com/" },
  { title: "ML Classification Lab", category: "AI / Machine Learning", description: "A classification experiment using model training, evaluation metrics and validation.", tech: ["Python", "Scikit-learn", "Pandas"], link: "https://github.com/" }
];

let databaseConnected = false;

mongoose.connect(process.env.MONGODB_URI)
  .then(() => { databaseConnected = true; console.log("MongoDB connected"); })
  .catch(err => console.warn("MongoDB not connected. Running with demo projects only:", err.message));

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", database: databaseConnected ? "connected" : "demo-mode" });
});

app.get("/api/projects", async (_req, res) => {
  try {
    if (!databaseConnected) return res.json(starterProjects);
    const projects = await Project.find().sort({ createdAt: -1 });
    res.json(projects.length ? projects : starterProjects);
  } catch (err) {
    res.status(500).json({ message: "Unable to load projects." });
  }
});

app.post("/api/projects", async (req, res) => {
  const { title, category, description, tech, link } = req.body;
  if (!title || !category || !description) {
    return res.status(400).json({ message: "Title, category and description are required." });
  }
  if (!databaseConnected) {
    return res.status(503).json({ message: "Connect MongoDB to save new projects." });
  }
  try {
    const project = await Project.create({ title, category, description, tech: tech || [], link: link || "" });
    res.status(201).json(project);
  } catch (err) {
    res.status(400).json({ message: "Could not save project." });
  }
});

app.post("/api/contact", async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) return res.status(400).json({ message: "Please complete all fields." });
  if (!databaseConnected) return res.status(503).json({ message: "Contact storage is unavailable until MongoDB is connected." });
  try {
    await Message.create({ name, email, message });
    res.status(201).json({ message: "Thanks! Your message has been received." });
  } catch (err) {
    res.status(500).json({ message: "Unable to send your message right now." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Portfolio running at http://localhost:${PORT}`));
